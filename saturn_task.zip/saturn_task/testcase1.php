<?php
// Include necessary PHP files (if any, for backend handling or routing)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Total Environment</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom Styles */
        body {
            font-family: 'Poppins', sans-serif;
        }
        .navbar {
            transition: background-color 0.3s;
        }
        .navbar.scrolled {
            background-color: white !important;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }
        .cta-button {
            border-radius: 7px;
            font-size: 14px;
        }
        .banner {
            background: url('img/banner.jpg') no-repeat center center;
            background-size: cover;
            height: 100vh;
            display: flex;
            align-items: center;
            color: white;
            text-align: left;
        }
        .banner h1 {
            font-size: 38px;
            text-transform: uppercase;
        }
        .banner p {
            margin-bottom: 10px;
        }
        .overview {
            padding: 50px 0;
        }
        .overview img {
            border-radius: 9px;
            transition: transform 0.3s;
        }
        .overview img:hover {
            transform: scale(1.05);
        }
        .footer {
            background-color: #F8F8F8;
            padding: 20px 0;
        }
    </style>
</head>
<body>

<!-- Header Section -->
<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">
            <img src="img/total-environment-logo.png" alt="Total Environment" width="208" height="36">
            <img src="img/srpl-logo.png" alt="SRPL" width="72" height="32" class="ms-3">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a href="#" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="#overview" class="nav-link">Overview</a></li>
                <li class="nav-item"><a href="#footer" class="nav-link">Contact</a></li>
            </ul>
            <a href="#" class="btn btn-primary cta-button ms-3">Get in Touch</a>
        </div>
    </div>
</nav>

<!-- Banner Section -->
<div class="banner d-flex">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <h1>In That Quiet Earth</h1>
                <p class="mb-1">By Total Environment</p>
                <p>Avalahalli Main Road, Off Hennur Road, North Bangalore</p>
                <p>RERA No: PRM/KA/RERA/1250/303/PR/080124/006538</p>
                <a href="#" class="btn btn-success cta-button mt-3">Book an Appointment</a>
            </div>
        </div>
    </div>
</div>

<!-- Overview Section -->
<section id="overview" class="overview">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <img src="img/overview.jpg" alt="Overview Image" class="img-fluid">
            </div>
            <div class="col-md-6">
                <h2 class="text-uppercase" style="color: #607A68;">Values of Intelligent Living</h2>
                <ul class="list-unstyled">
                    <li class="mb-2"><i class="fas fa-check-circle me-2" style="color: #607A68;"></i>4 Apartments Per Floor</li>
                    <li class="mb-2"><i class="fas fa-check-circle me-2" style="color: #607A68;"></i>Wooden Flooring</li>
                    <li class="mb-2"><i class="fas fa-check-circle me-2" style="color: #607A68;"></i>Double-Glazed Windows</li>
                    <li class="mb-2"><i class="fas fa-check-circle me-2" style="color: #607A68;"></i>Luxury Amenities</li>
                </ul>
                <a href="#" class="btn btn-primary mt-3">Enquire Now</a>
            </div>
        </div>
    </div>
</section>

<!-- Footer Section -->
<footer class="footer">
    <div class="container text-center">
        <img src="img/srpl-logo.png" alt="SRPL Logo" width="112" height="49" class="mb-3">
        <p>All Rights Reserved &copy; 2024 Saturn Realtors Private Limited</p>
        <a href="#" class="d-block">Privacy Policy</a>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Change navbar background on scroll
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        navbar.classList.toggle('scrolled', window.scrollY > 50);
    });
</script>
</body>
</html>
